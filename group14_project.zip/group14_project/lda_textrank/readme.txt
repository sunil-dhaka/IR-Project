lda_textrank.ipynb notebook implements LSA+Textrank model that we use to summaries multi-document articles.
To test on both English and Hindi, it takes about 1 hour.