--------------------------------------------------------------------------------------------
Plugins-
Software: No software needed. Just python3 is enough.

Environments: conda 4.10.3, python 3.8.5

Dependencies-
Python Libraries: pandas 1.1.3, numpy 1.19.2, networkx, rouge, sklearn , nltk

--------------------------------------------------------------------------------------------
Things to note:
On TIME:
textrank_notebook.ipynb takes about 15 minutes to give rouge score for 6000 test files(English), and 18000 test files(Hindi).
Space:
Word embeddings for both languages needs to be loaded into RAM for programme to run. At least 3-4 GB space is needed.
Test dataset also needs to be loaded into RAM.
--------------------------------------------------------------------------------------------
graph.ipynb analyses graph that we construct from similarity matrix.
--------------------------------------------------------------------------------------------