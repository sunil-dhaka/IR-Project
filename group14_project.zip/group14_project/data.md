# English Corpora
- [Multi News dataset](https://github.com/Alex-Fabbri/Multi-News)
    - Preprocessed tructed dataset [drive link](https://drive.google.com/open?id=1qqSnxiaNVEctgiz2g-Wd3a9kwWuwMA07)
    - we have used this dataset for training, validation and testing pursposes in our models
    - To run scripts download zip folder from drive and unzip it into data/ directory

# Hindi Corpora
- [News dataset](https://www.kaggle.com/datasets/disisbig/hindi-text-short-and-large-summarization-corpus)
    - download train and test csv files and move them into data/hi-data/ directory

# Glove Embeddings
- We have used 100d glove embeddings
- English language [glove embeddings](http://nlp.stanford.edu/data/glove.6B.zip)
    - download English glove embeddings and move them into data/glove/en/ folder
- Hindi language [glove embeddings](https://storage.googleapis.com/ai4bharat-public-indic-nlp-corpora/indiccorp/hi.tar.xz)
    - download Hindi glove embeddings and move them into data/glove/hi/ folder