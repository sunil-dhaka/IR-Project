from flask import Flask, render_template, request

from textrank_summarizer import *
from lda_summarizer import *

import langdetect
import json
import requests
import login

new_app=Flask(__name__)

headers={"Authorization": f"Bearer {login.API_TOKEN}"}
def query(payload,model_url):
    data = json.dumps(payload)
    response = requests.request("POST", model_url, headers=headers, data=data)
    return json.loads(response.content.decode("utf-8"))

@new_app.route('/')
def main_page():
    return render_template('index.html')

@new_app.route('/summaries',methods=['POST','GET'])
def textrank():
    text_data=request.form['input_data']
    lang=langdetect.detect(text_data)
    if lang=='hi':
        # change 'purnviram' to '.'
        text_data=text_data.replace(chr(2404),'.')
        summary_result_textrank = generate_summary(text_data)
        # change '.' to 'purnviram'
        summary_result_textrank=summary_result_textrank.replace('.',chr(2404))
        summary_result_lda=gen_summ(text_data)
        # change '.' to 'purnviram'
        summary_result_lda=summary_result_lda.replace('.',chr(2404))
        summary_result_lda_textrank=generate_summary_lda_textrank(text_data)
        # change '.' to 'purnviram'
        summary_result_lda_textrank=summary_result_lda_textrank.replace('.',chr(2404))

        # abstractive in hindi        
        summary_result_t5_small='model for hindi is not available'
        summary_result_pegasus='model for hindi is not available'

    else:
        summary_result_textrank = generate_summary(text_data)
        summary_result_lda=gen_summ(text_data)
        summary_result_lda_textrank=generate_summary_lda_textrank(text_data)

        # TODO: is it possible that model has been trained on multi-language corpora and with a seperate lang parameter in api-call we can do it for even hindi also  
        # abstractive api-calls for english
        t5_small_url='https://api-inference.huggingface.co/models/t5-small'
        google_pegasus_url='https://api-inference.huggingface.co/models/google/pegasus-multi_news'
        api_payload={
            "inputs":text_data,
            "parameters": {"do_sample": False} # what does this specifies
        }
        api_call_t5_small=query(api_payload,t5_small_url)
        api_call_pegasus=query(api_payload,google_pegasus_url)
        summary_result_t5_small=api_call_t5_small#[0]['summary_text']
        summary_result_pegasus=api_call_pegasus#[0]['summary_text'][2:]
    return render_template('summaries.html',result_lda_textrank=summary_result_lda_textrank,result_lda=summary_result_lda, result_textrank=summary_result_textrank, result_t5_small=summary_result_t5_small, result_pegasus=summary_result_pegasus)

if __name__=="__main__":
    new_app.run(debug=False)