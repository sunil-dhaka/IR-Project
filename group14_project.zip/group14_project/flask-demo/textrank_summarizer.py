import pandas as pd
import numpy as np
import nltk
import networkx as nx
from networkx.exception import PowerIterationFailedConvergence
from rouge import Rouge
from nltk.corpus import stopwords
nltk.download('stopwords')
print(stopwords.words('english'))
from nltk.tokenize import word_tokenize
import re
import nltk.data
from nltk.tokenize import sent_tokenize
nltk.download('punkt')
tokenizer = nltk.data.load('tokenizers/punkt/english.pickle')
import string

from nltk.stem import PorterStemmer
stemmer = PorterStemmer()
rouge_=Rouge()
import math
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.feature_extraction.text import CountVectorizer


# options: 50,100,200,300
EMBEDDING_SIZE=100
SENT_SUMMARY_COUNT=5
EN_DATA_PATH_SRC='../data/preprocessed_truncated/test.txt.src.tokenized.fixed.cleaned.final.truncated.txt' # ONLY ARTICLES
HI_EMBEDDINGS_PATH='../data/glove/hi/hi-d100-glove.txt'
EN_EMBEDDINGS_PATH='../data/glove/en/glove.6B.100d.txt'

"""
HELPER FUNCTIONS FOR MAIN SUMMARY GENERATION FUNC
"""
def sent_score(a,b):
    """
    implementation of sent score mentioned in the paper
    """
    words_a=a.split(' ')
    words_b=b.split(' ')
    # overlapping unigrams found in both sentences
    count=0
    for i in words_a:
        if i in words_b:
            count+=1

    score=count/(np.log(len(words_a))*np.log(len(words_b)))

    return score
    
def cosine_similarity(a,b):
    """
    func to compute cosine similarity
    """
    return np.dot(a,b)/((np.linalg.norm(a)+0.001)*(np.linalg.norm(b)+0.001))

def get_sent_vector(sentence):
    """
    func to get sentence vector = avg of word vectors
    """
    global glove_embeddings

    if len(sentence)!=0:
        sentence_vect=sum([glove_embeddings.get(word,np.zeros((EMBEDDING_SIZE,))) for word in sentence.split()])/(len(sentence.split())) # +0.001) # 0.001 to make things stable
    else:
        sentence_vect=np.zeros((EMBEDDING_SIZE,))
    return sentence_vect

def load_glove_model(file_path):
    """
    function to load glove embeddings from txt file into a dict
    """
    glove_model = {}
    with open(file_path,'r',encoding="utf-8",errors='ignore') as f:
        try:
            for i,line in enumerate(f):
                split_line = line.split()
                word = split_line[0]
                embedding = np.array(split_line[-EMBEDDING_SIZE:], dtype=np.float64)
                glove_model[word] = embedding
        except Exception as e:
            print(e)
            print(line,i)
    print(f"total {len(glove_model)} words loaded from glove model, each of size {EMBEDDING_SIZE}.")
    return glove_model

# load glove embeddings for both hindi and english
glove_embeddings=load_glove_model(file_path=EN_EMBEDDINGS_PATH)
hi_glove_embeddings=load_glove_model(file_path=HI_EMBEDDINGS_PATH)
# save all glove embeddings in a single dict
# this takes care of both languages that are present in hindi texts; although it makes overall process a bit slow
glove_embeddings.update(hi_glove_embeddings)


def generate_summary(article_text,similarity='sent'):
    """
    function to get summary of article text
    note: article text needs to be pre-processed; and that step only includes: string.lower()
    """
    # pre-process
    article_text=article_text.lower()
    # tokenize into sentences
    sent_tokens=sent_tokenize(article_text)
    # get sent vectores
    sent_vects=[]
    for sent in sent_tokens:
        sent_vects.append(get_sent_vector(sent))
    
    total_sents=len(sent_tokens)
    similarity_mat=np.zeros((total_sents,total_sents))

    if similarity=='cosine':
        for i in range(total_sents):
            for j in range(total_sents):
                # this way diag entries will be zeros
                if i!=j:
                    similarity_mat[i][j]=cosine_similarity(sent_vects[i],sent_vects[j])
    else:
        for i in range(total_sents):
            for j in range(total_sents):
                # this way diag entries will be zeros
                if i!=j:
                    similarity_mat[i][j]=cosine_similarity(sent_vects[i],sent_vects[j])

    # create graph from similarity matrix
    network_graph=nx.from_numpy_array(similarity_mat)
    """
    apply pagerank algo to get scores
    """
   
    scores=nx.pagerank(network_graph, alpha=0.85, max_iter=10000000)
    sorted_scores = sorted(((scores[i],sent_token) for i,sent_token in enumerate(sent_tokens)), reverse=True)

    # TODO: implement thershold version
    # in case some article does not have enough sentences
    if total_sents > SENT_SUMMARY_COUNT:
        summary_text=' '.join([sorted_scores[i][1] for i in range(SENT_SUMMARY_COUNT)])
    else:
        summary_text=' '.join([sorted_scores[i][1] for i in range(total_sents)])

    return summary_text

"""
LDA + TEXTRANK
"""
stop_words = set(stopwords.words('english'))
punc = '''!()-[]{};:'"\,<>./?@#$%^&*_~'''


def get_sent_vect(probe_text):
    """
    func to return sent vectors
    """

    break_sentences=tokenizer.tokenize(probe_text)
    clean_sentences=[]
    for item in break_sentences:
      item=item.translate(str.maketrans('', '', string.punctuation))
      item=' '.join( [w for w in item.split() if len(w)>1] )
      words = word_tokenize(item)
      words = [word for word in words if len(words)>1]
      words = [word.lower() for word in words]
      words = [word for word in words if word not in stop_words]
      item=' '.join(words)    
      clean_sentences.append(item)
    cln_summ=''
    cln_summ = '.'.join(clean_sentences)
    # print(cln_summ)
    #print(cln_summ)
    tfidf = CountVectorizer()
    response = tfidf.fit_transform([cln_summ])
    #print(response)
    unique_word_list = tfidf.get_feature_names_out()
    tf_idf={}
    for col in response.nonzero()[1]:
      tf_idf[unique_word_list[col]]= response[0, col]
    svd_matrix=np.zeros([len(unique_word_list),len(clean_sentences)])
    for i in range(0,len(clean_sentences)):
      sen=clean_sentences[i].split()
      for val in sen:
        #print(val)
        index=np.where(unique_word_list == val)
        index_length=len(index[0])
        if(index_length == 1):
          svd_matrix[index,i]=tf_idf[val]
    #print(svd_matrix)
    u,sigma,v_trans=np.linalg.svd(svd_matrix,full_matrices=False,compute_uv=True)
    sum_sigma=np.sum(sigma)
    iter_sum=0
    check_coverage=0
    for i in range(0,len(sigma)):
      iter_sum=iter_sum+sigma[i]
      percent_contribution=iter_sum/sum_sigma
      #print("the percent contributuin is ",percent_contribution)
      if(percent_contribution<0.70):
        check_coverage=i+1
    u_trimmed=u[:,:check_coverage]
    v_trimmed=v_trans[:check_coverage,:]

    sent_vects=[]
    for i,sent in enumerate(clean_sentences):
        # sent_words=sent.split(' ')
        tmp_=0
        for k,concept_weight in enumerate(v_trimmed[:,i]):
            foo_=0
            for j,word in enumerate(unique_word_list):
                if word in glove_embeddings:
                    # print('it is')
                    foo_+=u_trimmed[j,k]*glove_embeddings[word]
            tmp_+=np.abs(concept_weight)*foo_
        
        sent_vects.append(tmp_)
      
    return sent_vects

def generate_summary_lda_textrank(article_text):
    """
    function to get summary of article text
    """
    sent_tokens=sent_tokenize(article_text)
    try:
        sent_vects=get_sent_vect(article_text)
    except ValueError:
        return 0
    total_sents=len(sent_vects)
    similarity_mat=np.zeros((total_sents,total_sents))
    
    for i in range(total_sents):
        for j in range(total_sents):
            # this way diag entries will be zeros
            if i!=j:
                similarity_mat[i][j]=cosine_similarity(sent_vects[i],sent_vects[j])

    # create graph from similarity matrix
    network_graph=nx.from_numpy_array(similarity_mat)
    """
    apply pagerank algo to get scores
    """
    scores=nx.pagerank(network_graph, alpha=0.85, max_iter=10000000)
    sorted_scores = sorted(((scores[i],sent_token) for i,sent_token in enumerate(sent_tokens)), reverse=True)

    # TODO: implement thershold version
    # in case some article does not have enough sentences
    if total_sents > SENT_SUMMARY_COUNT:
        summary_text=' '.join([sorted_scores[i][1] for i in range(SENT_SUMMARY_COUNT)])
    else:
        summary_text=' '.join([sorted_scores[i][1] for i in range(total_sents)])

    return summary_text

if __name__=="__main__":
    # run on test data to get rouge score
    article_summary_list=[]
    with open(EN_DATA_PATH_SRC,'r') as file:
        for i,line in enumerate(file):
            print(i)
            article_summary_list.append(generate_summary(line.strip()))

    with open(f'en_article_summary_{EMBEDDING_SIZE}.txt','w') as file:
        file.write('\n'.join(article_summary_list))